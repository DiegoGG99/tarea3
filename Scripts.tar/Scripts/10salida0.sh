#!/bin/bash
echo "Este script tiene salida de $? "
