#!/bin/bash
var1=$/etc/apt/sources.list
var2=$/usr/bin/zip

if [ -x var1 ]
  then echo "es ejecutable"
  else
  echo "no es ejecutable"
fi
