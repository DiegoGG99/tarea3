#!/bin/bash
var=1;
while [ $var -lt 11 ];
do
if [ $var -ne 3 ] && [ $var -ne 9 ]; then
echo $var
fi
var=$((var+1))
done

echo Listo!



