#!/bin/bash
while true;
do echo " Presiona CTRL + C para salir del bucle";
sleep 60;
done
