#!/bin/bash
VAR1="Hola Mundo!!!";
echo $VAR1;
