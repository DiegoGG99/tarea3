#!/bin/bash
echo "Introduce el primer numero en el teclado";
read n1;
echo "n1 =" $n1;
echo "Introduce el segundo numero en el teclado";
read n2;
echo "n2 =" $n2;

if [[ $n1 -gt $n2 ]]; then
echo
echo $n1 "es mayor a" $n2
elif [[ $n1 -lt $n2 ]]; then
echo
echo $n2 "es mayor a" $n1
fi
if [[ $n1 -eq $n2 ]]; then
echo
echo $n1 "es igual a" $n2
fi


