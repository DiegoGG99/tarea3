echo "Escribe la primer palabra"
read p1;
echo "Escribe la segunda palabra"
read p2;

if [[ "$p1" = "$p2" ]]; then 
echo "$p1 es igual que $p2"
else
if [[ "$p1" > "$p2" ]]; then 
echo "$p2 es primero que $p1"
else
echo "$p1 es primero que $p2"
fi
fi
