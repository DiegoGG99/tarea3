#!/bin/bash
HN=$(hostname)
echo "Este script esta corriendo en el host" ---- $HN;

