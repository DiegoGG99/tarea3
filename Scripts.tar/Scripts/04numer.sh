#!/bin/bash
var=1;
for ((var;var<=100;var++));
do
echo "Este es el numero --" $var;
done

