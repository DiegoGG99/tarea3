#!/bin/bash
echo escribe un numero entero positivo para calcular su factorial:
read factorial
ans=1
while [ $factorial -gt 1 ]
do
let ans=$ans*$factorial
let factorial-=1
done
echo 'el resultado del factorial es' $ans
