#!/bin/bash
ls -a | wc -l

