#!/bin/bash
echo "Menu de administracion"
echo "1) Disco Duro"
echo "2) Archivos"
echo "3) Conexiones"
echo "4) Salir"
opc=0
echo Selecciona una opcion
read opc
case $opc in
1)
echo uso de disco duro
diskusage=$(du -s)
echo $diskusage K  Total
;;
2)
echo archivos viejos
old=$(find . / -atime 365)
echo $old

;;
3)
echo conexiones IPV4 e IPv6
ipv4=$(lsof -i 4)
ipv6=$(lsof -i 6)
echo $ipv4
echo $ipv6
;;
4)
echo "ByeBye!"
;;
esac


