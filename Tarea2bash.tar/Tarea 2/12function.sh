#!/bin/bash
cd /etc/apt/sources.list.d/
echo /etc/apt/sources.list.d/
ls -a | wc -l
echo
cd /var/lib/apt/lists/
echo /var/lib/apt/lists/
ls -a | wc -l
echo
cd /usr/bin
echo /usr/bin
ls -a | wc -l

