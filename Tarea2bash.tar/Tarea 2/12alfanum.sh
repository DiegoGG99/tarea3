#!/bin/bash
echo introduce una contraseña 
read password
if [[ $password =~ ^[A-Za-z0-9]+$ ]]; then
 echo es correcto
else
  echo no es valida por tener caracteres alfanumericos
fi
